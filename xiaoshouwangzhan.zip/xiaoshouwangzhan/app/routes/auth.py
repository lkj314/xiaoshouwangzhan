from flask import Blueprint, render_template, redirect, url_for
from flask_login import login_user, logout_user
from app.models.user import User
from .forms import LoginForm

bp = Blueprint('auth', __name__)

@bp.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    # ...登录逻辑...
    return render_template('auth/login.html', form=form)

@bp.route('/logout')
def logout():
    logout_user()
    return redirect(url_for('novels.index'))